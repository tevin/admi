class Main {
  public static void main(String[] args) {
    int times[] = new int[]{341, 273, 278, 329, 445, 402, 388, 275, 243, 334, 412, 393, 299,343, 317, 265};
  String[] names = {
            "Abdullah", "Tumo", "Cyrus", "Mwangi", "Ndungu", "Matt", "Alex",
            "Abel", "John", "James", "Jane", "Kiprotich", "Daniel", "Wilson",
            "Aaron", "William"
        };
        
    /*declaring variables*/
    int fastest= fastestTime(times);
    
    System.out.println("the fastest time ran was"+" "+fastest +" by " + names[4]);
  }
  
    
  public static int fastestTime(int[] times){
    /*declaring variable(s)*/
    int currentTime = times[0]; 
    
    for(int i=1;i < times.length;i++ /*for loop to check for the highest value in the array*/){ 
      if(times[i] > currentTime/*if statement to compare between the current time and the value in array*/){ 
         currentTime = times[i]; 
      } 
    } 
    return currentTime; 
  }
 
}